#ifndef SCHEMA_H
#define SCHEMA_H

#include "celldata.hpp"
#include "named_vector.hpp"

using Schema = NamedVector<DataType>;

#endif
