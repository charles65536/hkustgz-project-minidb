//
//  test2.hpp
//  miniSql_proj_finalPush
//
//  Created by 司徒健飞 on 2024/12/2.
//

#ifndef test2_hpp
#define test2_hpp


#include <stdio.h>
int main(int argc, char *argv[]);
#include "test_utils.hpp"
#endif /* test2_hpp */
